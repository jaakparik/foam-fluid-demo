
  # Filters Description Bar

  This is a code bundle for Filters Description Bar. The original project is available at https://www.figma.com/design/sXU6mv42AEjlA9J4kUwo9T/Filters-Description-Bar.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  