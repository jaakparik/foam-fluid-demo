// This section is now integrated into TalentInfoCard as the Platforms subcard
// Keeping this file for backwards compatibility but it's no longer used

export function PlatformMetricsSection() {
  return null;
}
