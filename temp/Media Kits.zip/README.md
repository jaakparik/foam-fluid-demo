
  # Left Hand Navigation  Media Kits

  This is a code bundle for Left Hand Navigation  Media Kits. The original project is available at https://www.figma.com/design/AXF0R8Nf1rHverMqAnSAb4/Left-Hand-Navigation--Media-Kits.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  