
  # Popover Filter Modal

  This is a code bundle for Popover Filter Modal. The original project is available at https://www.figma.com/design/bG0MQZdJdTv7QrBMujBzUy/Popover-Filter-Modal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  