
  # LHNa (Talent Profile)

  This is a code bundle for LHNa (Talent Profile). The original project is available at https://www.figma.com/design/vP70UyVAOOb3Uy476ZPmk8/LHNa--Talent-Profile-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  